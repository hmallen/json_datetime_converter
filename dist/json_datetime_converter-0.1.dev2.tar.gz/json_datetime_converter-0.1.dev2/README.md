# JSON Datetime Converter

Converts datetime object to and from iso-formatted dates while reading from and writing to json files.
